from przyklady.przyklady import infrastruktura_sieci

if __name__ == '__main__':
    infrastruktura_sieci()
